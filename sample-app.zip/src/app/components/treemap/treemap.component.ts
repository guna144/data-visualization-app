import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { TreeMap, TreeMapTooltip, TreeMapLegend } from '@syncfusion/ej2-angular-treemap';
import { IItemMoveEventArgs, ILoadEventArgs, TreeMapTheme, IItemClickEventArgs } from '@syncfusion/ej2-angular-treemap';

TreeMap.Inject(TreeMapTooltip, TreeMapLegend);

@Component({
  selector: 'app-treemap',
  templateUrl: './treemap.component.html',
  styleUrls: ['./treemap.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TreemapComponent implements OnInit {

  ngOnInit() {
  }

  // weightValuePath: string = 'Population';
  // leafItemSettings: object = {
  //     showLabels: true,
  //     labelPath: 'Country',
  //     fill: 'red',
  //     colorMapping: [
  //         {
  //             to: 10000000000,
  //             from: 100000000,
  //             label: '200M - 1.3M',
  //             color: '#4B134F'
  //         }, { to: 100000000, from: 20000000, label: '20M - 200M', color: '#8C304D' },
  //         { to: 20000000, from: 100000, label: '0.1M - 20M', color: '#C84B4B' }
  //     ]
  // };

  public itemMove= (args: IItemMoveEventArgs) => {
    args.item['data'].Sales = args.item['weight'];
    args.treemap.tooltipSettings.format = args.item['groupIndex'] === 0 ? 'Country: ${Continent}<br>Sales: ${Sales}' :
        'Country: ${Continent}<br>Company: ${Company}<br>Sales: ${Sales}';
  }
  public itemClick= (args: IItemClickEventArgs) => {
      args.item['data'].Sales = args.item['weight'];
      args.treemap.tooltipSettings.format = args.item['groupIndex'] === 0 ? 'Country: ${Continent}<br>Sales: ${Sales}' :
          'Country: ${Continent}<br>Company: ${Company}<br>Sales: ${Sales}';
  }
  public load = (args: ILoadEventArgs) => {
      let theme: string = location.hash.split('/')[1];
      theme = theme ? theme : 'Material';
      args.treemap.theme = <TreeMapTheme>(theme.charAt(0).toUpperCase() + theme.slice(1));
  }
  titleSettings: object = {
      text: 'Car Sales by Country - 2017',
      textStyle: {
          size: '15px'
      }
  };
  
  public tooltipSettings: object = {
      visible: true,
      format: 'Country: ${Continent}<br>Company: ${Company}<br>Sales: ${Sales}'
  };
  public legendSettings: object = {
      visible: true,
      position: 'Top',
      shape: 'Rectangle',
      mode: 'Interactive'
  };
  dataSource: object[] = CarSales;
  rangeColorValuePath: string = 'Population';
  weightValuePath: string = 'Sales';
  palette: string[] = ['#C33764', '#AB3566', '#993367', '#853169', '#742F6A', '#632D6C', '#532C6D', '#412A6F', '#312870', '#1D2671'];

  leafItemSettings: object = {
      showLabels: true,
      labelPath: 'Company',
      border: { color: 'white', width: 0.5 }
  };
  border: object = {
      color: 'white',
      width: 0.5
  };

  // public data: object[] = [{ fruit:'Apple', count:5000 },
  //                      { fruit:'Mango', count:3000 },
  //                      { fruit:'Orange', count:2300 },
  //                      { fruit:'Banana', count:500 },
  //                      { fruit:'Grape', count:4300 },
  //                      { fruit:'Papaya', count:1200 },
  //                      { fruit:'Melon', count:4500 }
  //   ];
  //   public leafItemSettings: object = {
  //        labelPath: 'fruit',
  //       colorMapping:[
  //           {
  //              from:500,
  //              to:3000,
  //              color:'orange'
  //          },
  //          {
  //              from:3000,
  //              to:5000,
  //              color:'green'
  //          }
  //       ]
  //   };
}


export let CarSales: object[] = [
  {Continent: "China", Company: "Volkswagen", Sales: 3005994 },
  {Continent: "China", Company: "General Motors", Sales: 1230044 },
  {Continent: "China", Company: "Honda", Sales: 1197023 },
  {Continent: "United States", Company: "General Motors", Sales:3042775  },
  {Continent: "United States", Company: "Ford", Sales:2599193  },
  {Continent: "United States", Company: "Toyota", Sales:2449587  },
  {Continent: "Japan",Company: "Toyota", Sales:1527977  },
  {Continent: "Japan", Company: "Honda", Sales:706982 },
  {Continent: "Japan", Company: "Suzuki", Sales:623041  },
  {Continent: "Germany",Company: "Volkswagen", Sales:655977  },
  {Continent: "Germany", Company: "Mercedes", Sales:310845  },
  {Continent: "Germany", Company: "BMW", Sales:261931  },
  { Continent: "United Kingdom", Company: "Ford ", Sales:319442  },
{Continent: "United Kingdom", Company: "Vauxhall", Sales: 251146 },
  { Continent: "United Kingdom", Company: "Volkswagen", Sales:206994  },
  {Continent: "India", Company: "Maruti Suzuki", Sales:1443654  },
   {Continent: "India", Company: "Hyundai", Sales:476241  },
  {Continent: "India", Company: "Mahindra", Sales:205041  },
  {Continent: "France", Company: "Renault", Sales:408183 },
  {Continent: "France", Company: "Peugeot", Sales:336242 },
  {Continent: "France", Company: "Citroen", Sales:194986  },
  { Continent: "Brazil", Company: "Flat Chrysler", Sales:368842  },
  { Continent: "Brazil", Company: "General Motors", Sales: 348351 },
  { Continent: "Brazil", Company: "Volkswagen", Sales: 245895 },
  {Continent: "Italy", Company: "Flat Chrysler", Sales:386260  },
  {Continent: "Italy", Company: "Volkswagen", Sales: 138984 },
  {Continent: "Italy", Company: "Ford", Sales: 125144 },
  {Continent: "Canada", Company: "Ford", Sales:305086},
  {Continent: "Canada", Company: "FCA", Sales:278011 },
  {Continent: "Canada", Company: "GM", Sales: 266884 },
     

]

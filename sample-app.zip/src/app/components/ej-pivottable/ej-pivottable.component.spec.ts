import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EjPivottableComponent } from './ej-pivottable.component';

describe('EjPivottableComponent', () => {
  let component: EjPivottableComponent;
  let fixture: ComponentFixture<EjPivottableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EjPivottableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EjPivottableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

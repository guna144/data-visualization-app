import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { ILoadEventArgs, ChartComponent } from '@syncfusion/ej2-angular-charts';
import { ChartSeriesType, EmptyPointMode, ChartTheme, AccumulationChart, IAccLoadedEventArgs, AccumulationTheme  } from '@syncfusion/ej2-charts';
import { ColorPickerEventArgs, ColorPickerComponent, ColorPickerMode } from '@syncfusion/ej2-angular-inputs';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ChartsComponent implements OnInit {

  @ViewChild('chart')
  public chart: ChartComponent;

  @ViewChild('colorpicker')
  public colorPicker: ColorPickerComponent;

  public primaryXAxis: Object;
  public primaryYAxis: Object;
  public chartData: Object[];
  public legendSettings: Object;
  public title: string;
  public marker: Object;
  public tooltip: Object;
  public zoom: Object;
  public animation: Object;
  public border: Object;
  public palette: string[];

  public data: Object[] = [
    { 'x': 'Chrome', y: 37, text: '37%' }, { 'x': 'UC Browser', y: 17, text: '17%' },
    { 'x': 'iPhone', y: 19, text: '19%' },
    { 'x': 'Others', y: 4, text: '4%' }, { 'x': 'Opera', y: 11, text: '11%' },
    { 'x': 'Android', y: 12, text: '12%' }
  ];

  ngOnInit(): void {
    
     // Title for chart
     this.title = 'Sales Analysis';
     // Legend for chart
     this.legendSettings = {
          visible: true
      }

    this.colorPicker.mode = 'Palette';
    this.colorPicker.dataBind();

    this.zoom = {
        enableSelectionZooming: true,
        enableMouseWheelZooming: true,
        enableScrollbar: true
        //toolbarItems: ['Zoom', 'Pan', 'Reset']
    };
    this.animation = { enable: true};

      // Tooltip for chart
     this.tooltip = {
        enable: true
     }

      // Data label for chart series
      this.marker = {
          dataLabel:{
              visible: true
          }
      };
      // Data for chart series
      this.chartData = [
          { month: 'Jan', sales: 35 }, { month: 'Feb', sales: 28 },
          { month: 'Mar', sales: 34 }, { month: 'Apr', sales: 32 },
          { month: 'May', sales: 40 }, { month: 'Jun', sales: 32 },
          { month: 'Jul', sales: 35 }, { month: 'Aug', sales: 55 },
          { month: 'Sep', sales: 38 }, { month: 'Oct', sales: 30 },
          { month: 'Nov', sales: 25 }, { month: 'Dec', sales: 32 }
      ];
    this.primaryXAxis = {
        valueType: 'Category'
    };
    this.primaryYAxis = {
      labelFormat: '${value}K'
    };
  }

  selectChart(selectedValue: any){
        
    this.chart.series[0].type = <ChartSeriesType>selectedValue;
    this.chart.refresh();
    
  }

  public load(args: IAccLoadedEventArgs): void {
    let selectedTheme: string = location.hash.split('/')[1];
    selectedTheme = selectedTheme ? selectedTheme : 'Material';
    args.accumulation.theme = <AccumulationTheme>(selectedTheme.charAt(0).toUpperCase() + selectedTheme.slice(1)).replace(/-dark/i, "Dark");
};

  // function to handle the ColorPicker change event
  public change(args: ColorPickerEventArgs): void {
    this.chart.series[0].fill = args.currentValue.hex;
  }

}

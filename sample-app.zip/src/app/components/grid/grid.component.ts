import { Component, OnInit ,  ViewChild, OnChanges, Input, SimpleChanges, SimpleChange } from '@angular/core';
// import { data } from './datasource';
import { RowSelectEventArgs } from '@syncfusion/ej2-angular-grids';
// import { customerData, data } from '../../../assets/data/master.detail.data';
import { CommonService } from '../../_services/common.service';
import { FilterSettingsModel,  GridComponent } from '@syncfusion/ej2-angular-grids';


@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponents implements OnInit {

  // public data: Object[];
  // public pageSettings: PageSettingsModel;
  
  // ngOnInit(): void {
  //     this.data = data;
  //     this.pageSettings = { pageSize: 6 };
  // }

    constructor(private commonService: CommonService){}

    public data: Object[];
    public initialPage: Object;
    public key: string = null;
    public dataLength: number;
    private pageNo: number = 1;
    private pageSize: number = 10;
    public filterOptions: FilterSettingsModel;
    private searchQuery: any;
    private columnName: string;
    private columnValue: string;
        
    @ViewChild('grid')
    public grid: GridComponent;

    public ngOnInit(): void {
        //this.data = customerData; //.filter((e: carType) => this.names.indexOf(e.CustomerID) !== -1);
        //this.initialPage = { pageSizes: true, pageCount: 4 };
        
        this.commonService.getCustomers(this.pageNo, this.pageSize).subscribe((records: any)=>{
            this.data = records.message; //.slice(start, start + 10);            
            this.dataLength = records.totalCount;
        });
        // this.commonService.getCustomer().subscribe((records: any[]) =>{
        //     console.log(data.length);
        //     console.log(records.length);
        //     this.dataLength = records.length;
        //     this.data = records;            ,
            // { field: 'CompanyName', matchCase: false, operator: 'startswith', predicate: 'and', value: 'Ana Trujillo Emparedados y helados' }
        // });
        // this.filterOptions = {
        //     type: 'Menu'
        // };
        // this.filterOptions = {
        //     columns: [{ field: 'ContactName', matchCase: false, operator: 'startswith', predicate: 'and', value: 'Ana Trujillo' }]
        // };
    }

    public onRowSelected(args: RowSelectEventArgs): void {
        //console.log('rowSelected : ',args.data);
        let record: carType = <carType>args.data;
        // this.key = record.ContactName;
        this.key = record.CustomerID;
    }

    paginationClick(args) {
        if (args.currentPage) {
            // console.log("currentPage: "+args.currentPage);
            this.pageNo = args.currentPage;
            //let start = (args.currentPage - 1) * 10;
            // this.commonService.getCustomers(this.pageNo, this.pageSize).subscribe((records: any)=>{
            //     this.data = records.message; //.slice(start, start + 10);            
            // });
            this.valueChange('',this.pageNo, this.pageSize);
        }
        
    }

    // public onChange(args: any): void {
    //     // console.log('args : ',args);
    //     // this.grid.filterByColumn('CompanyName', 'equal', args.target.value);
    //     this.columnName = args.target.id;
    //     let columnValue = args.target.value;

    //     this.searchQuery = JSON.stringify({ columnName : columnValue });
    //     console.log(this.searchQuery);
    //     this.commonService.searchCustomer(this.searchQuery).subscribe((records: any) => {
    //         this.data = records;
    //     });
    // }


    private jsonObject = {};
    valueChange(args:any, pageNo: number , pageSize: number): void {
        // console.log("args :",args);
        // this.grid.columns.length
        
        this.grid.columns.forEach(element => {
            this.columnName = element.field;
            if(args && args.target.id != null && args.target.id.split('_')[0] === this.columnName) {
                this.columnValue = args.target.value;
                if(this.columnValue == null || this.columnValue == "")
                    delete this.jsonObject[this.columnName];
                else
                    this.jsonObject[this.columnName] = this.columnValue;
            }
        });

        this.searchQuery = JSON.stringify(this.jsonObject);
        console.log(this.searchQuery);

        this.commonService.searchCustomer(this.searchQuery,pageNo,pageSize).subscribe((records: any) => {
            this.data = records.message;
            this.dataLength = records.totalCount;
        });
    }
    
}























@Component({
      selector: 'ejs-griddetail',
      templateUrl: 'detail.html'
})
export class DetailComponent implements OnInit, OnChanges {
      @Input()
      public key: string;
      public data: Object[];
      

      constructor(private commonService: CommonService){}

      ngOnInit(): void {
          this.data = [];
        //   this.filterOptions = {
        //     type: 'Menu'
        //  };
      }

      ngOnChanges(changes: SimpleChanges): void {

    //    console.log('changes : ',changes);

          let key: string = 'key';
          let change: SimpleChange = <SimpleChange>changes[key];
          
        //   console.log(data.filter((record: carType) => record.CustomerName === change.currentValue));

        //   this.data = data.filter((record: carType) => record.CustomerName === change.currentValue); //.slice(0, 5);          
        this.commonService.getOrders(change.currentValue).subscribe((records: any)=>{
            // console.log(records);
            this.data =  records;
        });
      }

}
type carType = { CustomerID: string, CustomerName: string, ContactName: string };
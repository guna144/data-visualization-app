import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Type } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { routes } from './app-routing.module';
import { AppComponent } from './app.component';
import { EjPivottableComponent } from './components/ej-pivottable/ej-pivottable.component';
import { HttpClientModule } from '@angular/common/http';
// import { EJ_PIVOTGRID_COMPONENTS } from 'ej-angular2/src/ej/pivotgrid.component';
import { RouterModule } from '@angular/router';
import { GridComponents ,DetailComponent } from './components/grid/grid.component';
import { HomeComponent } from './components/home/home.component';
// import { EJAngular2Module } from 'ej-angular2';
import { ChartModule, AccumulationChartAllModule } from '@syncfusion/ej2-angular-charts';
import { GridAllModule, PagerModule  } from '@syncfusion/ej2-angular-grids';
// import the PivotViewModule for the Pivot Grid component
import { PivotViewAllModule, PivotFieldListAllModule } from '@syncfusion/ej2-angular-pivotview';
import { ColorPickerModule, TextBoxModule } from '@syncfusion/ej2-angular-inputs';
import { DropDownListAllModule } from '@syncfusion/ej2-ng-dropdowns';
import { TreeMapAllModule } from '@syncfusion/ej2-angular-treemap';

// import { ChartComponent } from '@syncfusion/ej2-angular-charts';
import { CategoryService, LegendService, TooltipService, DataLabelService, LineSeriesService, ColumnSeriesService, 
         ZoomService, ScrollBarService, SelectionService } from '@syncfusion/ej2-angular-charts';
import { PageService, SortService, FilterService, GroupService, ReorderService, } from '@syncfusion/ej2-angular-grids';
import { ChartsComponent } from './components/chart/charts.component';
import { PivotTableComponent } from './components/pivot-table/pivot-table.component';
import { TreemapComponent } from './components/treemap/treemap.component';

@NgModule({
  declarations: [
    AppComponent,
    EjPivottableComponent,
    // EJ_PIVOTGRID_COMPONENTS,
    GridComponents, DetailComponent,
    HomeComponent,
    ChartsComponent,
    PivotTableComponent,
    TreemapComponent//,
    // ChartComponent
  ],
  imports: [
    BrowserModule,ChartModule,GridAllModule,PivotViewAllModule, PivotFieldListAllModule, ColorPickerModule, AccumulationChartAllModule,PagerModule , TextBoxModule, FormsModule,
    RouterModule.forRoot(routes,{ useHash: true}),TreeMapAllModule,
    HttpClientModule,DropDownListAllModule
    // AppRoutingModule
    
    // EJAngular2Module.forRoot()
  ],
  providers: [CategoryService, LineSeriesService, LegendService, TooltipService, DataLabelService , ColumnSeriesService, ZoomService, ScrollBarService,SelectionService,
              PageService, SortService, FilterService, GroupService, ReorderService, FilterService ],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EjPivottableComponent } from './components/ej-pivottable/ej-pivottable.component';
import { GridComponents } from '../app/components/grid/grid.component';
import { HomeComponent } from '../app/components/home/home.component';
import { ChartsComponent } from './components/chart/charts.component';
import { PivotTableComponent } from '../app/components/pivot-table/pivot-table.component';
import { TreemapComponent } from '../app/components/treemap/treemap.component';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'grid', component: GridComponents },
    { path: 'chart', component: ChartsComponent },
    { path: 'pivotTable', component: PivotTableComponent },
    { path: 'treemap', component: TreemapComponent }
];

// @NgModule({
//   imports: [RouterModule.forRoot(routes)],
//   exports: [RouterModule]
// })
// export class AppRoutingModule { }

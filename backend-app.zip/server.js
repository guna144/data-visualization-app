const express = require('express');
const bodyParser = require('body-parser');
const mongo = require('mongoose');
const router = express.Router();
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
const cors = require('cors');

const db = mongo.connect("mongodb://localhost:27017/AngularData", { useNewUrlParser: true }, function(err, response){
    if(err) console.log(err);
    else console.log('DB Connected'); // to ' +  db, ' + ', response);
});

const app = express();

app.use('/api',router);
router.use(cors());

app.use(bodyParser.json({limit:'5mb'}));
app.use(bodyParser.urlencoded({extended:true}));

var Schema = mongo.Schema;

var CustomerDataShema = new Schema({
    CustomerID: { type: String },
    ContactName: { type: String },
    CompanyName: { type: String },
    Address: { type: String },
    Country: { type: String }
});

CustomerDataShema.plugin(mongooseAggregatePaginate);

var model = mongo.model('customerData', CustomerDataShema, 'customerdata');

router.get("/filterCustomers", (req, res) => {
    var query = JSON.parse(req.query.searchQuery);
    var pageNo = parseInt(req.query.pageNo);
    var size   = parseInt(req.query.size);
    // find users above 18 by city
    var aggregate = model.aggregate();
    aggregate.match(query);
    //.group({ _id: '$city' , count : { '$sum' : 1 } })
    var options = { page : pageNo, limit : size}

    // callback
    model.aggregatePaginate(aggregate, options, function(err, results, pageCount, count) {
   
          // console.log(results);
        // console.log(results, pageCount, count)
        if(err) response = {"error":true, "message":"Error fetching data"};
        else {
            response = {"error":false, "message": results, "totalCount": count};
        }
        res.send(response);
        
      });
   
    // Promise
    // model.aggregatePaginate(aggregate, options)
    // .then(function(value) {
    //     console.log(value.data, value.pageCount, value.totalCount)
    //     if(err) response = {"error":true, "message":"Error fetching data"};
    //     else {
    //         response = {"error":false, "message": value.data, "totalCount": value.totalCount};
    //     }
    //     res.send(response);
    // })
    // .catch(function(err){ 
    //   console.err(err)
    // });
});


var OrderDataShema = new Schema({
    OrderID : Number,
    CustomerID : String,
    CustomerName : String,
    OrderDate : Date,
    ShippedDate : Date,
    Freight : Number,
    ShipName : String,
    ShipAddress : String,
    ShipCity : String,
    ShipRegion : String,
    ShipCountry : String
});


// var model = mongo.model('customerData', CustomerDataShema, 'customerdata');

router.post("/saveCustomer", (req, res) => {
    var mod = new model(req.body);
    //console.log(req.body);
    if(req.body != null){
        mod.save(function(err, data){
            if(err) res.send(err);
            else res.send({data: "Record has been Inserted!"});
        });
    }
});

router.get("/getCustomers", (req, res, next) => {
    model.find({}, function(err, data){
        if(err) res.send(err);
        else res.send(data);
    })
});

router.get("/customers", (req, res) => {
    var pageNo = parseInt(req.query.pageNo);
    var size   = parseInt(req.query.size);
    var query = {};
    if(pageNo < 0 || pageNo === 0){
        response = {"error":true, "message" : "Invalid page number, should start with 1"};
        return res.json(response);
    }
    query.skip = size * (pageNo -1)
    query.limit = size;
    // find some documents
    model.countDocuments({}, function(err, totalCount){
        if(err) response = {"error" : true,"message" : "Error fetching data"};
        
        model.find({}, {}, query, function(err, data){
            if(err) response = {"error":true, "message":"Error fetching data"};
            else {
                var totalPages = Math.ceil(totalCount / size);
                response = {"error":false, "message": data, "totalCount": totalCount};
            }
            res.send(response);
        });
    });
    
});







// /** This API for filter the customer data based on the search ceritria */
// var model1 = mongo.model('customerData', CustomerDataShema, 'customerdata');

// router.get("/filterCustomers", (req, res) => {
//     var query = JSON.parse(req.query.searchQuery);

//      CustomerDataShema.plugin(mongooseAggregatePaginate);
//         // find users above 18 by city
//       var aggregate = model1.aggregate();
//       aggregate.match(query);
//         //.group({ _id: '$city' , count : { '$sum' : 1 } })
//       var options = { page : 1, limit : 10};

//           // Promise
//       // model.aggregatePaginate(aggregate, options)
//       //   .then(function(value) {
//       //     console.log(value.data, value.pageCount, value.totalCount);
//       //     res.end();
//       //   })
//       //   .catch(function(err){ 
//       //     console.err(err)
//       //   });

//     // callback
//     model1.aggregatePaginate(aggregate, options, function(err, results, pageCount, count) {
//         if(err) 
//         {
//           console.err(err)
//         }
//         else
//         { 
//           console.log(results)
//         }
//       });
   
// });





/** This API for filter the customer data based on the search ceritria */
// router.get("/filterCustomers", (req, res) => {
//     var query = JSON.parse(req.query.searchQuery);
//     console.log('Search Query : ',req.query.searchQuery);

//     var pageNo = 1;
//     var size   = 10
//     // var pageNation = {};
//     if(pageNo < 0 || pageNo === 0){
//         response = {"error":true, "message" : "Invalid page number, should start with 1"};
//         return res.json(response);
//     }
//     //query.skip = size * (pageNo -1)
//     //query.limit = size;
//     // find some documents
//     model.countDocuments({}, function(err, totalCount){
//         if(err) response = {"error" : true,"message" : "Error fetching data"};

//         model.find(query).skip((size * pageNo) - size)
//         .limit(size).exec(function(err, data){
//             // model.count().exec(function(err, count){
//                 if(err) response = {"error":true, "message":"Error fetching data"};
//                 else {
//                     var totalPages = Math.ceil(totalCount / size); // "totalCount": totalCount
                    
//                      console.log('Data : ',data.length);
//                     // var totalPages = Math.ceil(count / size);
//                     console.log('Count : ',totalPages);
//                     response = {"error":false, "message": data, totalCount : totalPages};
//                 }
//                 // if(err) res.send(err);
//                 // else res.send(data);
//                 res.send(response);
//             // });
           
//         });
//     });
// });






var orderModel = mongo.model('orderData', OrderDataShema,'OrderData');
router.get("/getorders", (req, res) => {
   //const { filter, skip, limit, sort, projection } = aqp(req.query);

    // console.log(req.query.CustomerID);

    let searchQuery = queryVar(req.query.CustomerID);

    orderModel.find({CustomerID:searchQuery}, function(err, data){
        if(err) res.send(err);
        else res.send(data);
    });
});


let queryVar = function(queryString) {
    return queryString.replace( /\r\n/g, '').replace(/^\s+|\s+$/, '').replace(/[^a-z\s]+/gi, '').replace(/\s+$/, '');
};


app.listen(9090, function(){
    console.log("App listing on port 9090");
});
